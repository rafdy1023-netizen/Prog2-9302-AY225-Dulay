module AttendanceTracker {
    requires java.desktop; 
}
